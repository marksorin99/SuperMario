package com.tutorial.mario;

import com.tutorial.mario.entity.Entity;
import com.tutorial.mario.tile.Tile;
import com.tutorial.mario.tile.Wall;

import java.awt.*;
import java.util.LinkedList;

public class Handler {

    public LinkedList<Entity> entity = new LinkedList<Entity>();//ci aiuta su render, sono liste
    public LinkedList<Tile> tile  = new LinkedList<Tile>();

    public Handler(){
        createLevel();
    }

    public void render (Graphics g){//metodo
        for(Entity en:entity){//for loop che crea entity di nome en per ogni entity nel List
            en.render(g);//e fare il render di ognuno
        }

        for(Tile ti:tile){//for loop che crea tile di nome ti per ogni tile nel List
            ti.render(g);//fa render di ognuno
        }

    }
    public void tick (){//metodo
        for(Entity en:entity){//for loop che crea entity di nome en per ogni entity nel List
            en.tick();//e fare il tick di ognuno
        }

        for(Tile ti:tile){//for loop che crea tile di nome ti per ogni tile nel List
            ti.tick();//fa tick di ognuno
        }

    }

    public void addEntity(Entity en ){
        entity.add(en);
    }

    public void removeEntity(Entity en){
        entity.remove(en);
    }

    public void addTile(Tile ti){
        tile.add(ti);
    }

    public void removeTile(Tile ti){
        tile.remove(ti);
    }

    public void createLevel(){
        for(int i=0;i<Game.WIDTH*Game.SCALE/64+1;i++){//perch� width wall 64*64
            addTile(new Wall(i*64,Game.HEIGHT*Game.SCALE-64,64,64,true,Id.wall ,this));
            if(i!=0 && i!=1 && i!=15 && i!=16 && i!=17 )
                addTile(new Wall(i*64,300,64,64,true,Id.wall,this));
        }
    }

}
