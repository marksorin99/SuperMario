package com.tutorial.mario;

import java.awt.Canvas;
import java.awt.Dimension;

import javax.swing.JFrame;

import com.tutorial.mario.gfx.Sprite;
import com.tutorial.mario.gfx.SpriteSheet;
import com.tutorial.mario.input.KeyInput;
import com.tutorial.mario.entity.Player;
import com.tutorial.mario.tile.Wall;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;

public class Game extends Canvas implements Runnable {

    public static final int WIDTH = 270;//altezza frame da creare
    public static final int HEIGHT = WIDTH/14*10;//larghezza
    public static final int SCALE = 4;//scala
    public static final String TITLE= "MARIO";

    private Thread thread;//serve per il gameloop
    private boolean running = false;

    public static Handler handler;
    public static SpriteSheet sheet;
    
    public static Sprite grass;
    public static Sprite player;

    public Game(){//costruttore
        Dimension size = new Dimension(WIDTH*SCALE,HEIGHT*SCALE);//dimensioni
        setPreferredSize(size);
        setMaximumSize(size);
        setMinimumSize(size);
    }
    private void init(){//initialize (inizializzazione)
        handler = new Handler();
        sheet = new SpriteSheet("/spritesheet.png");//il nome del nostro png

        addKeyListener(new KeyInput());//diamo al nostro frame un keylistener
        
        grass = new Sprite(sheet,1,1);//coordinate del terreno sull'immagine 
        player = new Sprite (sheet,2,1);

        handler.addEntity(new Player(100,400,64,64,true,Id.player,handler));
       // handler.addTile(new Wall(200,200,64,64,true,Id.wall,handler));//facciamo muro ostacolo
    }

    private synchronized void start() {
          /*synchronized protegge il thread da interferenze e memorie di area
          e serve per il gameloop*/
        if(running) return;//se � gia iniziato non lo iniziamo, sicurezza in pi�
        running =true;
        thread = new Thread(this,"Thread");
        thread.start();

    }

    private synchronized void stop() {
        if(!running)return;
        running = false;
        try {
            thread.join();/*risky code, prova a farlo, se qulcosa non va lo ferma e scrive l'errore
                        .join fa si che thread sia finito prima di passare alla prossima istruzione */
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
    @Override
    public void run() {//run pu� essere fatto 1 sola volta
        //vogliamo mettere timer per aggiornare render e tick
        init();
        requestFocus();//il frame va in focus ogni volta che facciamo girare il programma
        long lastTime = System.nanoTime();
        long timer = System.currentTimeMillis();
        double delta = 0.0;
        double ns = 1000000000.0/60.0;//nanoseconds
        int frames = 0;
        int ticks = 0;
        while (running){//inizio game loop, finche running fai render e tick
            long now = System.nanoTime();
            delta+=(now-lastTime)/ns;//delta=frames+ticks
            lastTime = now;
            while(delta>=1){
                tick();
                ticks++;
                delta--;
            }
            render();
            frames++;
            if(System.currentTimeMillis()-timer > 1000){
                timer+=1000;
                System.out.println(frames + " frames al secondo  " + ticks + "  updates al secondo");
                frames =0;
                ticks =0;
            }
        }
        stop();
    }

    public void render (){//rendering la grafica( metterla a schermo)
        BufferStrategy bs = getBufferStrategy();
        if (bs==null){
            createBufferStrategy(3);
            return;
        }
        Graphics g = bs.getDrawGraphics();
        g.setColor(Color.BLACK);//colore dello sfondo anche con RGB color
        g.fillRect(0,0,getWidth(),getHeight());
        handler.render(g);
        g.dispose();//fa vedere quel che abbiamo creato sopra
        bs.show();

    }

    public void tick(){//aggiorno, update
        handler.tick();
    }

    public static void main(String[] args){
        Game game = new Game();
        JFrame frame = new JFrame(TITLE);//il nome del frame
        frame.add(game);
        frame.pack();//mettiamo tutto insieme
        frame.setResizable(false);//lasciamo la grandezza sempre la stessa
        frame.setLocationRelativeTo(null);//mettiamo la finestra al centro dello schermo
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        game.start();

    }



}

