package com.tutorial.mario.gfx;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class SpriteSheet {
    private BufferedImage sheet ;
    public SpriteSheet(String path){//dando il nome del file la prende da src i dati e lo trasforma in BufferedImage
        //e poi setta i sheets nel bufferedimage
        try {
            sheet = ImageIO.read(getClass().getResource(path));//abbiamo messo in comunicazione
            //questo e cartella res, dove si trova la spritesheet
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public BufferedImage getSprite(int x, int y){
        return sheet.getSubimage(x*32-32,y*32-32,32,32);
    }
}